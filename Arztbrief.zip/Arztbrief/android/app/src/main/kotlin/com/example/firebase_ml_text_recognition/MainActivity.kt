package com.example.firebase_ml_text_recognition

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
